# NADF ERP — Control Tower

**Last updated:** 2026-06-16  
**Updated by:** BPOGS Engagement Session  
**Next mandatory update:** After next completed milestone

---

## Current State Summary

| Field | Value |
|-------|-------|
| **Current Phase** | Phase 1 — Business Process Documentation & ERP Configuration |
| **Current Active Department** | Legal Services Unit (LSU) — BPMN Swimlane Production |
| **Current Active Milestone** | M-LSU-05: Legal P5 AS-IS Swimlane + Legal P4–P6 Detailed TO-BE Swimlanes |
| **Overall Programme Completion** | ~35% |
| **Current Git Branch** | *(to be populated from repo)* |
| **Current PR Status** | *(to be populated from repo)* |

---

## Phase Completion Table

| Phase | Description | Status | % Complete |
|-------|-------------|--------|-----------|
| Phase 0 | Engagement Setup, Workbook Framework, Master Guide | ✅ Complete | 100% |
| Phase 1 | Business Process Documentation (All 12 Departments) | 🔄 In Progress | ~45% |
| Phase 2 | Odoo ERP Configuration & Module Setup | 🔄 In Progress (parallel) | ~30% |
| Phase 3 | UAT, Super User Training, Acceptance | ⏳ Not Started | 0% |
| Phase 4 | Production Deployment & Go-Live | ⏳ Not Started | 0% |
| Phase 5 | Hypercare, Stabilisation, Phase 2 Features | ⏳ Not Started | 0% |

---

## Department Completion Table — BPMN Swimlane Diagrams

| Department | Processes | AS-IS Complete | TO-BE Complete | Status |
|-----------|-----------|---------------|---------------|--------|
| HR | 8 | ✅ All | ✅ All | Done |
| Procurement | 6 | ✅ All | ✅ All | Done |
| Finance | 7 | ✅ All | ✅ All | Done |
| Administration | ~5 | ✅ All | ✅ All | Done |
| Project Coordination | 5 | ✅ All (P1–P5) | ✅ All (P1–P5) | Done |
| Strategy & Planning | 5 | ⏳ Queued | ⏳ Queued | Not Started |
| Legal Services Unit | 6 | 🔄 P1–P4 done, P5 in progress | 🔄 P1–P3 done | In Progress |
| Communications | ~5 | ⏳ Queued | ⏳ Queued | Not Started |
| Sustainable Agriculture | ~5 | ⏳ Queued | ⏳ Queued | Not Started |
| Investment | ~5 | ⏳ Queued | ⏳ Queued | Not Started |
| Monitoring & Evaluation | ~5 | ⏳ Queued | ⏳ Queued | Not Started |
| Executive Management | ~4 | ⏳ Queued | ⏳ Queued | Not Started |

**Total processes mapped (AS-IS + TO-BE):** ~61 processes across 12 departments  
**Swimlane HTML files produced:** ~55+ approved files

---

## Department Completion Table — ERP (Odoo) Configuration

| Department/Module | Odoo Module | Status | Notes |
|------------------|-------------|--------|-------|
| Finance | Accounting, Invoicing | 🔄 Phase 1 live | Chart of accounts, vendor bills configured |
| Procurement | Purchase, Inventory | 🔄 Phase 1 live | Procurement pipeline configured |
| HR | HR, Payroll, Leave | 🔄 Phase 1 live | Employee records, org chart active |
| Administration | Admin module | 🔄 Partial | Fleet, assets configured |
| Approvals | Approvals | 🔄 Configured | Multi-level approval flows |
| Asset Management | Assets | 🔄 Configured | Asset register populated |
| Fleet | Fleet | 🔄 Configured | Vehicle register active |
| ICT Helpdesk | Helpdesk | 🔄 Configured | Kanban and analytics active |
| Project Coordination | Project | ⏳ Queued | Awaiting TO-BE completion |
| Strategy & Planning | — | ⏳ Not started | — |
| Legal | — | ⏳ Not started | Awaiting diagram completion |
| Investment | — | ⏳ Not started | — |

---

## Current Blockers

| # | Blocker | Department | Owner | Status |
|---|---------|-----------|-------|--------|
| B-01 | Legal P5 AS-IS swimlane not yet delivered | Legal | BPOGS Analyst | 🔄 In progress |
| B-02 | Procurement P1 RACI inversion on step 1.19 (DEC-PROC-01) — awaiting client confirmation | Procurement | Client | ⏳ Pending |
| B-03 | Procurement P1 missing priority/timeline data on steps DEC-PROC-03/04 | Procurement | Client | ⏳ Pending |
| B-04 | Strategy workbooks not yet uploaded for swimlane production | Strategy | Aliyu | ⏳ Pending |
| B-05 | Multiple departments: outstanding gaps consolidated in `NADF_BPOGS_PendingActions_ClientClarifications.docx` | All | Client | ⏳ Pending |

---

## Current Risks

| ID | Risk | Likelihood | Impact | Mitigation |
|----|------|-----------|--------|-----------|
| R-01 | Client clarification delays blocking TO-BE finalisation | Medium | High | Pending actions document maintained; gaps flagged explicitly |
| R-02 | Remaining 6 departments not yet workbook-uploaded — sequencing risk | Medium | High | Queue established; upload-on-demand approach |
| R-03 | Odoo Community vs Enterprise feature gap undisclosed in reports | Low | High | Enterprise assumed throughout; confirmed Odoo 17 EE |
| R-04 | Swimlane diagram standards drift across sessions (cold-start AI) | Medium | Medium | 27-page onboarding manual + master guide in every session zip |
| R-05 | UAT not started; go-live date not fixed | Medium | High | Phase 3 gate not yet opened |

---

## Next 5 Actions

| # | Action | Owner | Dependency |
|---|--------|-------|-----------|
| 1 | Complete Legal P5 AS-IS swimlane (dual START triggers, HLSU note) | BPOGS Analyst | Workbook uploaded |
| 2 | Produce Legal P4 Detailed TO-BE swimlane | BPOGS Analyst | P5 AS-IS approved |
| 3 | Produce Legal P5 & P6 Detailed TO-BE swimlanes | BPOGS Analyst | P4 TO-BE approved |
| 4 | Upload Strategy department workbooks and begin Strategy P1–P5 AS-IS + TO-BE | Aliyu → Analyst | Legal complete |
| 5 | Resolve Procurement RACI/data blockers (B-02, B-03) and finalise pending actions document | Aliyu + Client | Client response |

---

## Last Completed Milestone

**M-PC-05:** Project Coordination — All 5 processes AS-IS + Detailed TO-BE swimlanes complete and approved (PC1–PC5).

---

## Next Milestone

**M-LSU-05:** Legal Services Unit — Complete Legal P5 AS-IS + Legal P4–P6 Detailed TO-BE. Approve all Legal swimlanes.

---

## System Status

| Item | Status | Notes |
|------|--------|-------|
| Odoo Database | 🟢 Live | Odoo 17 Enterprise; Phase 1 modules active |
| Backup Status | ⚠️ Unknown | Confirm with Aliyu |
| Test Status | 🔄 Partial | Super User Acceptance Testing at 50% |
| UAT Status | 🔄 In Progress | 50% complete |
| Production Deployment | 🔄 70% | Phase 1 modules deployed |
| Git Branch | *(populate from repo)* | — |
| PR Status | *(populate from repo)* | — |

---

*This file must be updated after every completed milestone. It is the authoritative source for current programme state.*
