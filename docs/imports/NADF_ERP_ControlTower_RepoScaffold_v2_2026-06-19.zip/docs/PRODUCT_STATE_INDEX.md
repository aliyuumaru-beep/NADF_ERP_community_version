# NADF ERP — Product State Index

**Purpose:** This file is the mandatory first read for any new Claude Code session, AI agent, developer, or operator joining the NADF ERP programme. It tells you exactly which files to read and what each one is authoritative for.

---

## START HERE — Session Initialisation Sequence

Read in this order before touching any code or configuration:

| # | File | Why |
|---|------|-----|
| 1 | `docs/CONTROL_TOWER.md` | Current phase, milestone, blockers, next actions |
| 2 | `docs/PRODUCT_BACKLOG.md` | All work items, priorities, statuses |
| 3 | `docs/MILESTONE_REGISTER.md` | Milestone history and current milestone detail |
| 4 | `docs/NADF_PRODUCT_ROADMAP.md` | Overall programme roadmap (create if absent) |
| 5 | `docs/NADF_PRODUCT_ARCHITECTURE.md` | Technical architecture decisions (create if absent) |
| 6 | `docs/DECISION_LOG.md` | All major product and architecture decisions |
| 7 | `docs/IMPLEMENTATION_HISTORY.md` | Completed milestones and what was done |
| 8 | `CHANGELOG.md` | Latest changes |
| 9 | Current department status file (`docs/departments/status/`) | Active department detail |
| 10 | Git status (`git log --oneline -20`, `git status`) | Repo state |

---

## Authority Matrix

| Question | Authoritative Document |
|----------|----------------------|
| What is the current phase and milestone? | `docs/CONTROL_TOWER.md` |
| What is the overall roadmap and sequencing? | `docs/NADF_PRODUCT_ROADMAP.md` |
| What decisions have been made and why? | `docs/DECISION_LOG.md` |
| What work has been completed? | `docs/IMPLEMENTATION_HISTORY.md` |
| What work remains? | `docs/PRODUCT_BACKLOG.md` |
| What is the current state of a department? | `docs/departments/status/<dept>_status.md` |
| What is the technical architecture? | `docs/NADF_PRODUCT_ARCHITECTURE.md` |
| What changed in the last session? | `CHANGELOG.md` + latest `docs/session_logs/` |

---

## Mandatory Session Start Protocol

After reading the above files, answer these questions before beginning any work:

1. What is the current phase?
2. What is the current active milestone?
3. What are the current blockers?
4. What is the next recommended action?

**Do not begin work until this state has been loaded and confirmed.**

---

## Mandatory Session End Protocol

1. Update `docs/CONTROL_TOWER.md`
2. Update `docs/PRODUCT_BACKLOG.md` (change statuses as appropriate)
3. Update `docs/MILESTONE_REGISTER.md`
4. Update relevant department status file
5. Update `docs/IMPLEMENTATION_HISTORY.md`
6. Update `docs/DECISION_LOG.md` if any decision was made
7. Update `CHANGELOG.md`
8. Create `docs/session_logs/YYYY-MM-DD_SESSION_SUMMARY.md`

**No milestone is complete until all control documents are updated.**

---

## Department Status Files

| Department | File |
|-----------|------|
| Finance | `docs/departments/status/finance_status.md` |
| Procurement | `docs/departments/status/procurement_status.md` |
| HR | `docs/departments/status/hr_status.md` |
| Administration | `docs/departments/status/admin_status.md` |
| Project Coordination | `docs/departments/status/project_coordination_status.md` |
| Strategy & Planning | `docs/departments/status/strategy_status.md` |
| Communications | `docs/departments/status/communications_status.md` |
| Sustainable Agriculture | `docs/departments/status/sustainable_agriculture_status.md` |
| Investment | `docs/departments/status/investment_status.md` |
| Monitoring & Evaluation | `docs/departments/status/me_status.md` |
| Executive Management | `docs/departments/status/executive_management_status.md` |
| Legal Services Unit | `docs/departments/status/legal_status.md` |

---

*Last updated: 2026-06-16*

---

## Claude Desktop / Claude Code Boundary Rule

**Claude Desktop** has access only to NADF project materials in its project folder (workbooks, swimlane outputs, ERP mappings, process documents). It does not have access to:
- `/Users/mac/nadf_erp` (local repository)
- `/Users/mac/odoo17` (Odoo instance)
- GitHub repository state
- Odoo database
- Local addons, configs, or Git history

Claude Desktop may only state: *"Based on the NADF project materials available in this Claude Desktop project folder…"*

**Claude Code** is responsible for:
1. Receiving the transfer package (`NADF_FULL_PRODUCT_TRANSFER_PACKAGE.md`)
2. Running repository and Odoo discovery before any implementation
3. Maintaining all control documents in the repo
4. Implementing milestones, managing GitHub governance, PRs, CI, backups, and test evidence

**Transfer package:** `NADF_FULL_PRODUCT_TRANSFER_PACKAGE.md` — paste this into Claude Code to initiate any new implementation session.

## Claude Code Session Start — Discovery First

Before implementing anything, Claude Code must verify:
- Local repo path and Git status
- GitHub remote and branch protection
- CI workflows
- Odoo version and database
- Addons path and existing custom modules
- Existing governance docs
- Backup status

Only after discovery report is confirmed may implementation begin.
