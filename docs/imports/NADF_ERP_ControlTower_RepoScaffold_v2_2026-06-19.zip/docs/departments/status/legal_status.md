# Legal Services Unit (LSU) — Department Status

**Last updated:** 2026-06-16  
**Status:** 🔄 In Progress

---

## Department Objective
Document and optimise all Legal Services Unit processes covering contract management, legal advisory, compliance, litigation, and document lifecycle across NADF operations.

## Processes Identified
| # | Process | AS-IS | TO-BE |
|---|---------|-------|-------|
| P1 | Procurement Contracts | ✅ Done | ✅ Done |
| P2 | (Legal P2 — name from workbook) | ✅ Done | ✅ Done |
| P3 | (Legal P3 — name from workbook) | ✅ Done | ✅ Done |
| P4 | (Legal P4 — name from workbook) | ✅ Done | ⏳ Not Started |
| P5 | (Legal P5 — name from workbook) | 🔄 In Progress | ⏳ Not Started |
| P6 | (Legal P6 — if exists) | ⏳ Not Started | ⏳ Not Started |

## Key Design Decisions (LSU-specific)
- Counterparties share the ES/CEO lane — no standalone counterparty column
- HLSU does not get a separate lane in P5; accountability note used instead
- Dual START triggers permitted in P5
- END marker in column of final acting party

## Odoo Coverage
- Legal module: Not started (awaiting diagram completion)
- Document management: Queued (Phase 2)

## Implementation Status
- AS-IS diagrams: 4/6 approved, 1 in progress
- TO-BE diagrams: 3/6 approved

## Current Blockers
- Legal P5 AS-IS in production
- Legal P4–P6 TO-BE awaiting P5 AS-IS approval

## Next Action
Complete Legal P5 AS-IS; present for approval; proceed to P4 TO-BE.
