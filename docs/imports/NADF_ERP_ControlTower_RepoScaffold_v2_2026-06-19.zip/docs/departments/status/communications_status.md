# Communications — Department Status

**Last updated:** 2026-06-16  
**Status:** ⏳ Not Started

## Processes Identified: ~5 (estimated)
## AS-IS Swimlanes: ⏳ Not Started
## TO-BE Swimlanes: ⏳ Not Started

## Blocker
Queued after Strategy & Planning department.

## Next Action
Upload Communications workbooks when Strategy is complete.
