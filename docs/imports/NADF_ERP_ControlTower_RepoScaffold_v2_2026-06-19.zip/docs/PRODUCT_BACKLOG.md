# NADF ERP — Product Backlog

**Last updated:** 2026-06-16  
**Total items:** See per-department sections below

---

## Backlog Item Format

| Field | Description |
|-------|-------------|
| ID | Unique backlog item ID |
| Process Ref | Process number and name |
| Requirement | What must be delivered |
| Source | Source document |
| Priority | P1 Critical / P2 High / P3 Medium / P4 Low |
| Type | Native / Configure / OCA / Custom / Future |
| Status | Not Started / In Progress / Blocked / Done / Deferred |
| Dependencies | What must be done first |
| Acceptance Criteria | How we know it is done |

---

## FINANCE

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| FIN-001 | F-P1 Budget Planning | AS-IS swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| FIN-002 | F-P1 Budget Planning | Detailed TO-BE swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| FIN-003 | F-P2 Revenue Collection | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| FIN-004 | F-P3 Expenditure Management | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| FIN-005 | F-P4 Financial Reporting | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| FIN-006 | F-P5–P7 | Remaining Finance process swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| FIN-007 | All Finance | Odoo Accounting module — chart of accounts, vendor bills, invoicing | Workbooks | P1 | Configure | ✅ Done | Odoo live | Odoo live, transactions processing |
| FIN-008 | All Finance | Executive financial dashboard in Odoo | Requirements | P2 | Configure | 🔄 In Progress | Odoo live | Dashboard rendering in Odoo |
| FIN-009 | All Finance | Two-factor authentication for Finance users | Security | P1 | Configure | 🔄 In Progress | Odoo live | 2FA enforced on Finance login |

---

## PROCUREMENT

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| PROC-001 | P-P1 Capital & Recurrent Procurement | AS-IS + TO-BE swimlanes | Workbook v2.0 | P1 | — | ✅ Done | — | HTML approved (B-02, B-03 open) |
| PROC-002 | P-P2 to P-P6 | Remaining Procurement process swimlanes | Workbooks | P1 | — | ✅ Done | — | HTML approved |
| PROC-003 | P-P1 | Resolve RACI inversion step 1.19 DEC-PROC-01 | Client clarification | P1 | — | ❌ Blocked | Client confirmation | RACI confirmed, diagram updated |
| PROC-004 | P-P1 | Resolve missing priority/timeline DEC-PROC-03/04 | Client clarification | P2 | — | ❌ Blocked | Client data | Data received, diagram updated |
| PROC-005 | All Procurement | Odoo Purchase module — procurement pipeline | Workbooks | P1 | Configure | ✅ Done | Odoo live | Purchase orders processing |

---

## HR

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| HR-001 | HR-P1 to HR-P8 | All HR AS-IS + TO-BE swimlanes | Workbooks | P1 | — | ✅ Done | — | All 16 HTML files approved |
| HR-002 | All HR | Odoo HR module — employee records, org chart, leave management | Workbooks | P1 | Configure | ✅ Done | Odoo live | Employee records active |
| HR-003 | HR-P6 Benefits & Retirement | Odoo payroll and benefits configuration | Workbook | P2 | Configure | 🔄 In Progress | HR-002 | Benefits processing in Odoo |

---

## ADMINISTRATION

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| ADM-001 | All Admin | AS-IS + TO-BE swimlanes | Workbooks | P1 | — | ✅ Done | — | HTML approved |
| ADM-002 | Fleet | Odoo Fleet module — vehicle register | Workbooks | P2 | Configure | ✅ Done | Odoo live | Fleet records active |
| ADM-003 | Assets | Odoo Asset Management — asset register | Workbooks | P2 | Configure | ✅ Done | Odoo live | Asset register populated |
| ADM-004 | ICT | Odoo Helpdesk — ICT helpdesk kanban | Workbooks | P2 | Configure | ✅ Done | Odoo live | Helpdesk tickets processing |
| ADM-005 | Facility | Odoo Facility Management | Requirements | P3 | OCA/Custom | 🔄 In Progress | Phase 2 | Facility requests tracked |
| ADM-006 | Energy/Fleet | Vehicle Management System (fuel tracking) | Requirements | P3 | Configure | 🔄 In Progress | ADM-002 | Fuel logs in Odoo |

---

## PROJECT COORDINATION

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| PC-001 | PC-P1 Project Initiation | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| PC-002 | PC-P2 Project Planning | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| PC-003 | PC-P3 Project Execution | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| PC-004 | PC-P4 Monitoring & Control | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| PC-005 | PC-P5 Project Closure | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ✅ Done | — | HTML approved |
| PC-006 | All PC | Odoo Project module configuration | Workbooks | P2 | Configure | ⏳ Not Started | TO-BE complete | Project tasks in Odoo |

---

## STRATEGY & PLANNING

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| STR-001 | STR-P1 Strategy Development | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ⏳ Not Started | Workbooks uploaded | HTML approved |
| STR-002 | STR-P2 | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ⏳ Not Started | STR-001 done | HTML approved |
| STR-003 | STR-P3 | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ⏳ Not Started | STR-002 done | HTML approved |
| STR-004 | STR-P4 | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ⏳ Not Started | STR-003 done | HTML approved |
| STR-005 | STR-P5 | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ⏳ Not Started | STR-004 done | HTML approved |
| STR-006 | All Strategy | Odoo configuration for strategy tracking | Workbooks | P3 | Future | ⏳ Not Started | TO-BE complete | TBD |

---

## LEGAL SERVICES UNIT

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| LSU-001 | LSU-P1 Procurement Contracts | AS-IS swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| LSU-002 | LSU-P2 | AS-IS swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| LSU-003 | LSU-P3 | AS-IS swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| LSU-004 | LSU-P4 | AS-IS swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| LSU-005 | LSU-P5 | AS-IS swimlane (dual START, HLSU note) | Workbook | P1 | — | 🔄 In Progress | — | HTML approved |
| LSU-006 | LSU-P1 | Detailed TO-BE swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| LSU-007 | LSU-P2 | Detailed TO-BE swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| LSU-008 | LSU-P3 | Detailed TO-BE swimlane | Workbook | P1 | — | ✅ Done | — | HTML approved |
| LSU-009 | LSU-P4 | Detailed TO-BE swimlane | Workbook | P1 | — | ⏳ Not Started | LSU-005 approved | HTML approved |
| LSU-010 | LSU-P5 | Detailed TO-BE swimlane | Workbook | P1 | — | ⏳ Not Started | LSU-009 approved | HTML approved |
| LSU-011 | LSU-P6 (if exists) | AS-IS + TO-BE swimlanes | Workbook | P1 | — | ⏳ Not Started | LSU-010 approved | HTML approved |
| LSU-012 | All Legal | Odoo Legal module configuration | Workbooks | P2 | Custom/OCA | ⏳ Not Started | TO-BE complete | TBD |

---

## COMMUNICATIONS

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| COM-001 to COM-010 | COM-P1 to COM-P5 | AS-IS + TO-BE swimlanes (all processes) | Workbooks | P1 | — | ⏳ Not Started | Workbooks uploaded | HTML approved |
| COM-011 | All Comms | Odoo configuration | Workbooks | P3 | Future | ⏳ Not Started | TO-BE complete | TBD |

---

## SUSTAINABLE AGRICULTURE

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| SA-001 to SA-010 | SA-P1 to SA-P5 | AS-IS + TO-BE swimlanes | Workbooks | P1 | — | ⏳ Not Started | Workbooks uploaded | HTML approved |
| SA-011 | All SA | Odoo configuration | Workbooks | P3 | Future | ⏳ Not Started | TO-BE complete | TBD |

---

## INVESTMENT

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| INV-001 to INV-010 | INV-P1 to INV-P5 | AS-IS + TO-BE swimlanes | Workbooks | P1 | — | ⏳ Not Started | Workbooks uploaded | HTML approved |
| INV-011 | All Investment | Odoo Investment/Loan module | Workbooks | P2 | Custom | ⏳ Not Started | TO-BE complete | TBD |

---

## MONITORING & EVALUATION

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| ME-001 to ME-010 | ME-P1 to ME-P5 | AS-IS + TO-BE swimlanes | Workbooks | P1 | — | ⏳ Not Started | Workbooks uploaded | HTML approved |
| ME-011 | All M&E | Odoo reporting/dashboard configuration | Workbooks | P2 | Configure | ⏳ Not Started | TO-BE complete | TBD |

---

## EXECUTIVE MANAGEMENT

| ID | Process Ref | Requirement | Source | Priority | Type | Status | Dependencies | Acceptance Criteria |
|----|------------|-------------|--------|----------|------|--------|-------------|-------------------|
| EXEC-001 to EXEC-008 | EXEC-P1 to EXEC-P4 | AS-IS + TO-BE swimlanes | Workbooks | P1 | — | ⏳ Not Started | Workbooks uploaded | HTML approved |
| EXEC-009 | All Exec | Odoo executive dashboard | Workbooks | P1 | Configure | 🔄 In Progress | Odoo live | Dashboard active |

---

## CROSS-FUNCTIONAL WORKFLOWS

| ID | Requirement | Priority | Type | Status |
|----|------------|---------|------|--------|
| XFN-001 | Multi-department approval workflow (Budget → Procurement → Finance) | P1 | Configure | ⏳ Not Started |
| XFN-002 | Document management and retention workflow | P2 | OCA | ⏳ Not Started |
| XFN-003 | Cross-department notification and escalation matrix | P2 | Configure | ⏳ Not Started |

---

## REPORTING AND DASHBOARDS

| ID | Requirement | Priority | Type | Status |
|----|------------|---------|------|--------|
| RPT-001 | Executive financial dashboard | P1 | Configure | 🔄 In Progress |
| RPT-002 | Procurement spend analytics | P2 | Configure | ⏳ Not Started |
| RPT-003 | HR headcount and leave dashboard | P2 | Configure | ⏳ Not Started |
| RPT-004 | Project status dashboard | P2 | Configure | ⏳ Not Started |
| RPT-005 | M&E KPI dashboard | P2 | Custom | ⏳ Not Started |

---

## SECURITY AND ACCESS RIGHTS

| ID | Requirement | Priority | Type | Status |
|----|------------|---------|------|--------|
| SEC-001 | Two-factor authentication for all users | P1 | Configure | 🔄 In Progress |
| SEC-002 | Role-based access control matrix (all departments) | P1 | Configure | ⏳ Not Started |
| SEC-003 | Audit log configuration | P1 | Configure | ⏳ Not Started |
| SEC-004 | Data backup and recovery procedure | P1 | Configure | ⚠️ Unknown |

---

## AI / AUTOMATION ENHANCEMENTS

| ID | Requirement | Priority | Type | Status |
|----|------------|---------|------|--------|
| AI-001 | Automated document routing via Odoo approval workflows | P2 | Configure | ⏳ Not Started |
| AI-002 | Automated notification triggers for overdue tasks | P2 | Configure | ⏳ Not Started |
| AI-003 | Automated financial variance alerts | P3 | Custom | ⏳ Not Started |

---

## PUBLIC SECTOR TEMPLATE EXTRACTION

| ID | Requirement | Priority | Type | Status |
|----|------------|---------|------|--------|
| PST-001 | Extract reusable public sector Odoo configuration template from NADF implementation | P4 | Future | ⏳ Not Started |
| PST-002 | Package swimlane production methodology as reusable framework | P4 | Future | ⏳ Not Started |

---

*This backlog must be updated after every milestone. Statuses must reflect reality at time of update.*
