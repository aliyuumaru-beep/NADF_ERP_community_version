# NADF ERP — Decision Log

**Last updated:** 2026-06-16

---

## Decision Status Legend
- 🔒 Locked — not reversible without formal change request
- ✅ Active — current and in effect
- ⚠️ Revisable — may be revisited

---

| ID | Date | Context | Decision | Rationale | Impact | Reversibility | Related Files |
|----|------|---------|----------|-----------|--------|--------------|---------------|
| DEC-001 | 2026 (early) | ERP platform selection | **Odoo 17 Enterprise** selected as the NADF ERP platform | Best fit for public sector; Arabic/English support; strong procurement and HR modules; upgrade path to v18 | All configuration and custom modules built on Odoo 17 EE | 🔒 Low — significant migration cost to reverse | Architecture docs |
| DEC-002 | 2026 (early) | Community vs Enterprise | **Odoo Community Edition must never appear in client-facing documents** | Enterprise features are required; Community mention undermines confidence and contractual position | All reports, diagrams, and docs reference Odoo 17/18 EE only | 🔒 Locked | All status reports |
| DEC-003 | 2026 (early) | Swimlane diagram format | **Browser-rendered HTML with SVG overlay** selected for BPMN swimlane diagrams | No dependency on licensed BPMN tools; portable; visually precise; client-renderable in any browser | All swimlane HTML files follow this format | 🔒 Locked | `NADF_SWIMLANE_MASTER_GUIDE.md` |
| DEC-004 | 2026 (early) | Diagram source sheets | **`1_Refined_AS-IS` sheet** → AS-IS diagrams; **`3_Detailed_TO-BE` sheet** → TO-BE diagrams. `2_Executive_TO-BE` is never used for production diagrams | Executive TO-BE is a summary layer; Detailed TO-BE contains full step data needed for swimlane production | All workbook extractions must target these specific sheets | 🔒 Locked | All workbook Python scripts |
| DEC-005 | 2026 (early) | Step ID convention | **`-TO` suffix** on step IDs (e.g. `1.0A-TO`) confirms correct Detailed TO-BE sheet extraction | Prevents silent extraction from wrong sheet | QA step: always verify suffix present | 🔒 Locked | All TO-BE extraction scripts |
| DEC-006 | 2026 (early) | Swimlane arrow rendering | **SVG arrows must use `z-index:9999` and `will-change:transform`** to prevent being hidden behind table cells | Browser rendering bug: table cells occlude SVG without these properties | Applied to all arrow SVG elements in all diagrams | 🔒 Locked | All HTML swimlane files |
| DEC-007 | 2026 (early) | SVG colour syntax | **`fill="#ffffff" fill-opacity="0.93"` must be used** instead of `rgba()` in SVG fill attributes | `rgba()` is not valid SVG presentation attribute syntax; causes rendering failures in some browsers | All SVG box fills use hex + opacity attributes | 🔒 Locked | All HTML swimlane files |
| DEC-008 | 2026 (early) | Odoo automation badge | **"AUTOMATED — NO USER ACTION" lime badge** must appear on all fully automated Odoo system boxes in TO-BE diagrams | Visual distinction required to differentiate human and system steps for client clarity | Applied to all `odoo-box` class elements | 🔒 Locked | All TO-BE HTML files |
| DEC-009 | 2026 (early) | AS-IS Odoo references | **All Odoo references must be stripped from AS-IS diagrams** | AS-IS represents current state pre-ERP; including Odoo references is factually incorrect | QA check on all AS-IS files | 🔒 Locked | All AS-IS HTML files |
| DEC-010 | 2026 (early) | Loop-back arrows | **Loop-back "No" arrows must route through the empty left corridor (x=80)** — `loopLeft` label oriented vertically on right side of corridor arrow | Prevents arrows cutting through populated box areas; maintains diagram readability | Enforced in all gateway-with-rejection diagrams | 🔒 Locked | `NADF_SWIMLANE_MASTER_GUIDE.md` |
| DEC-011 | 2026 (early) | Handover step layout | **Handover steps must always be two boxes occupying two lanes** | A handover by definition involves two actors; single-lane handover misrepresents accountability | Enforced across all departments | 🔒 Locked | All swimlane files |
| DEC-012 | 2026 (early) | END marker placement | **END marker must be positioned in the column of the final acting party**, not always LSU | Accuracy of process closure accountability | Enforced per-process based on TO-BE data | 🔒 Locked | All swimlane files |
| DEC-013 | 2026 (early) | Counterparty lane treatment | **Counterparties are not standalone RACI actors**; they share the ES/CEO lane rather than receiving their own column | Counterparties are external; giving them a lane inflates diagram complexity and misrepresents governance | Enforced in all relevant diagrams | 🔒 Locked | Legal swimlanes |
| DEC-014 | 2026 (Legal P5) | HLSU lane treatment | **HLSU (Head of LSU) does not receive a separate lane in Legal P5**; instead, an accountability note is added to the relevant step | HLSU approval is a sign-off, not a discrete process actor with multiple steps; separate lane adds clutter | Applied to Legal P5 AS-IS | ✅ Active | Legal P5 HTML |
| DEC-015 | 2026 (Legal P5) | Multiple start triggers | **Dual START triggers** are permitted where a process can be initiated by more than one event | Some processes have two legitimate triggers (e.g. scheduled + ad hoc); forcing a single trigger misrepresents reality | Applied to Legal P5 AS-IS | ✅ Active | Legal P5 HTML |
| DEC-016 | 2026 (early) | RACI circular reference | **Circular RACI** (role appears as both Responsible and Informed on their own step) must be flagged and corrected before diagram production | Logical inconsistency; a role cannot inform themselves | Checked at Stage 2 (RACI audit) for all processes | ✅ Active | All workbooks |
| DEC-017 | 2026 (early) | Workbook extraction tool | **`openpyxl` with `data_only=True`**is the required Python tool for workbook extraction | `data_only=True` returns cell values not formulas; required for accurate data extraction from xlsx | All extraction scripts use this flag | 🔒 Locked | All Python extraction scripts |
| DEC-018 | 2026 (early) | JS validation method | **`sed` + `node --check`** pattern is the mandatory JS validation step before presenting any HTML diagram | Catches syntax errors before client sees the file | Enforced after every HTML file generation | 🔒 Locked | QA checklist |
| DEC-019 | 2026 (early) | docx assembly approach | **Multi-module Node.js** with `docx` library; `add()` must flatten arrays via `Array.isArray(e)` check | Standard Node docx library behaviour requires this flattening pattern | Applied to all docx generation scripts | 🔒 Locked | Manual/report generation scripts |
| DEC-020 | 2026 (early) | Ampersand encoding | **Ampersands in SVG text content must be written as `&amp;`** or replaced with "and" | Raw `&` is invalid XML/SVG and causes rendering/parsing failures | Applied to all SVG text content | 🔒 Locked | All HTML swimlane files |

---

*Every major product, architecture, scope, or implementation decision must be recorded here on the date it is made.*
