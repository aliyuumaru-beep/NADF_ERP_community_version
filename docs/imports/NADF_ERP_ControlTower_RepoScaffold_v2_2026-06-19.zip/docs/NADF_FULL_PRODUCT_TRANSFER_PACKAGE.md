# NADF FULL PRODUCT TRANSFER PACKAGE

**Prepared by:** Claude Desktop (NADF BPOGS Project Folder)  
**Date:** 2026-06-16  
**Destination:** Claude Code — NADF ERP Local Repository  
**Authority statement:** All information in this document is based exclusively on the NADF project materials available in the Claude Desktop project folder. Claude Desktop has not inspected `/Users/mac/nadf_erp`, `/Users/mac/odoo17`, the GitHub repository, the Odoo database, local addons, local configs, or local Git history. All repository-side facts must be verified by Claude Code before any implementation begins.

---

## SECTION 1 — PRODUCT VISION

**Client:** National Agricultural Development Fund (NADF)  
**Consultant:** Lanasoft Technologies  
**Product:** NADF Business Process Optimisation and Governance System (BPOGS) — implemented on Odoo 17 Enterprise  
**Upgrade path:** Odoo 18 Enterprise (planned)

**Vision:** Replace all manual, paper-based, and siloed departmental workflows at NADF with a unified, auditable, automated ERP system on Odoo 17 Enterprise — fully aligned with documented and optimised business processes across all 12 NADF departments, and governed by BPMN-standard swimlane process maps.

**Non-negotiable constraint:** Odoo Community Edition must never be referenced in any client-facing document, report, diagram, or code comment.

---

## SECTION 2 — BUSINESS PROCESS SCOPE

### Methodology
Each department's processes are documented in three layers:
1. **Refined AS-IS** — current state (from workbook sheet `1_Refined_AS-IS`)
2. **Detailed TO-BE** — future optimised state with Odoo integration (from sheet `3_Detailed_TO-BE`)
3. **Executive TO-BE** — summary layer (sheet `2_Executive_TO-BE`) — never used for production diagrams

### Deliverable per process
- Browser-rendered HTML swimlane diagram (AS-IS and Detailed TO-BE)
- RACI matrix embedded in workbook
- Odoo system step badges on all automated TO-BE steps

### Total scope
- **12 departments**
- **61+ processes** (exact count to be verified by Claude Code against workbooks)
- **~120+ HTML swimlane files** (AS-IS + TO-BE per process)

---

## SECTION 3 — DEPARTMENT-BY-DEPARTMENT REQUIREMENTS

### 3.1 HR
- **Processes:** P1–P8 (8 processes)
- **AS-IS swimlanes:** Complete (all 8 approved)
- **TO-BE swimlanes:** Complete (all 8 approved)
- **Odoo modules required:** `hr`, `hr_payroll`, `hr_leave`, `hr_attendance`
- **Status:** Swimlanes done; Odoo Phase 1 live; benefits/payroll config in progress
- **Outstanding:** Benefits and retirement plan (HR-P6) Odoo configuration; UAT

### 3.2 Finance
- **Processes:** P1–P7 (7 processes)
- **AS-IS swimlanes:** Complete (all 7 approved)
- **TO-BE swimlanes:** Complete (all 7 approved)
- **Odoo modules required:** `account`, `account_payment`, `account_budget`
- **Status:** Odoo Phase 1 live; executive dashboard and 2FA in progress
- **Outstanding:** Executive financial dashboard; 2FA enforcement; UAT

### 3.3 Procurement
- **Processes:** P1–P6 (6 processes)
- **AS-IS swimlanes:** Complete (all 6 approved)
- **TO-BE swimlanes:** Complete (all 6 approved — two open blockers)
- **Odoo modules required:** `purchase`, `stock`, `purchase_requisition`
- **Status:** Odoo Phase 1 live
- **Open blockers:**
  - B-02: RACI inversion on step 1.19 (DEC-PROC-01) — awaiting client confirmation
  - B-03: Missing priority/timeline data on DEC-PROC-03/04 — awaiting client data

### 3.4 Administration
- **Processes:** ~5
- **AS-IS swimlanes:** Complete
- **TO-BE swimlanes:** Complete
- **Odoo modules required:** `fleet`, `maintenance`, `helpdesk`
- **Status:** Fleet, assets, ICT helpdesk configured; facility management and fuel tracking in progress

### 3.5 Project Coordination
- **Processes:** P1–P5 (5 processes)
- **AS-IS swimlanes:** Complete (all 5: v1.0–v1.3)
- **TO-BE swimlanes:** Complete (all 5: v2.0)
- **Process list:** P1 Project Initiation, P2 Project Planning, P3 Project Execution, P4 Monitoring & Control, P5 Project Closure
- **Odoo modules required:** `project`, `project_milestone`
- **Status:** Swimlanes done; Odoo Project module not yet configured

### 3.6 Strategy & Planning
- **Processes:** ~5 (exact count pending workbook upload)
- **AS-IS swimlanes:** Not started
- **TO-BE swimlanes:** Not started
- **Status:** Queued — workbooks not yet uploaded
- **Odoo modules required:** TBD after TO-BE completion

### 3.7 Legal Services Unit (LSU) — ACTIVE DEPARTMENT
- **Processes:** P1–P6 (P6 existence to be confirmed)
- **AS-IS swimlanes:** P1–P4 approved; P5 in production; P6 not started
- **TO-BE swimlanes:** P1–P3 approved; P4–P6 not started
- **Odoo modules required:** Custom/OCA legal module (TBD)
- **Key design rules (locked):**
  - Counterparties share ES/CEO lane — no standalone counterparty column
  - HLSU does not receive a separate lane; accountability note used
  - Dual START triggers permitted in P5
  - END marker in column of final acting party
- **Outstanding:** P5 AS-IS; P4–P6 TO-BE

### 3.8 Communications
- **Processes:** ~5 (pending workbook upload)
- **Status:** Not started; queued after Strategy

### 3.9 Sustainable Agriculture
- **Processes:** ~5 (pending workbook upload)
- **Status:** Not started

### 3.10 Investment
- **Processes:** ~5 (pending workbook upload)
- **Odoo note:** Investment/Loan module likely requires custom development
- **Status:** Not started

### 3.11 Monitoring & Evaluation (M&E)
- **Processes:** ~5 (pending workbook upload)
- **Odoo note:** M&E KPI dashboard likely requires custom development
- **Status:** Not started

### 3.12 Executive Management
- **Processes:** ~4 (pending workbook upload)
- **Odoo note:** Executive dashboard in progress
- **Status:** Not started (swimlanes); ERP partially in progress

---

## SECTION 4 — REFINED AS-IS / TO-BE SUMMARY

### Swimlane production standards (all locked — do not deviate)
| Rule | Standard |
|------|----------|
| Diagram format | Browser-rendered HTML with SVG arrow overlay |
| Arrow orientation | Orthogonal only — no diagonals |
| Loop-back routing | Through left corridor (x=80); loopLeft label vertical on right side |
| Handover steps | Always two boxes in two lanes |
| END marker | In column of final acting party |
| Automated Odoo boxes | Must carry "AUTOMATED — NO USER ACTION" lime badge |
| AS-IS Odoo references | Must be stripped entirely |
| SVG fill syntax | `fill="#ffffff" fill-opacity="0.93"` — no rgba() |
| Ampersands in SVG | Must be `&amp;` or replaced with "and" |
| Arrow z-index | `z-index:9999` + `will-change:transform` |
| JS validation | `sed -n '/<script>/,/<\/script>/p' file.html \| grep -v '<script>' \| grep -v '</script>' > /tmp/check.js && node --check /tmp/check.js` |
| Workbook extraction | `openpyxl` with `data_only=True` |
| Sheet targets | AS-IS: `1_Refined_AS-IS`; TO-BE: `3_Detailed_TO-BE` |
| TO-BE step ID confirmation | Step IDs carry `-TO` suffix (e.g. `1.0A-TO`) |
| Circular RACI | Flag and correct before diagram production |
| Counterparties | Share ES/CEO lane — no standalone column |
| RACI notation | Responsible / Accountable / Consulted / Informed — explicit per step |

### Gold-standard reference
A canonical gold-standard HTML swimlane file exists and was approved by the client. All new diagrams must visually match it. Location: in client's swimlane outputs folder (Claude Code must request this file if not in repo).

---

## SECTION 5 — ERP MAPPING SUMMARY

### Confirmed Odoo module assignments
| Department | Odoo Module(s) | Status |
|-----------|---------------|--------|
| Finance | account, account_payment | ✅ Live |
| Procurement | purchase, stock | ✅ Live |
| HR | hr, hr_payroll, hr_leave | ✅ Live |
| Administration | fleet, maintenance, helpdesk | ✅ Live |
| Project Coordination | project | ⏳ Pending config |
| Legal | Custom/OCA | ⏳ TBD |
| Strategy | TBD | ⏳ TBD |
| Communications | TBD | ⏳ TBD |
| Sustainable Agriculture | TBD | ⏳ TBD |
| Investment | Custom (loan/investment) | ⏳ TBD |
| M&E | Custom (KPI dashboard) | ⏳ TBD |
| Executive | Reporting/dashboards | 🔄 In progress |

### Odoo system step pattern (TO-BE diagrams)
Every fully automated step in the TO-BE diagrams is a system action. These steps:
- Appear in the **Odoo System** lane
- Carry the lime "AUTOMATED — NO USER ACTION" badge
- Are sourced from the `3_Detailed_TO-BE` workbook sheet
- Are tagged with the `-TO` step ID suffix

---

## SECTION 6 — SWIMLANE REFERENCES

### Completed and approved swimlane files (Claude Desktop knowledge)
| Department | Files |
|-----------|-------|
| HR | HR-P1 through HR-P8 AS-IS + TO-BE (16 files) |
| Finance | FIN-P1 through FIN-P7 AS-IS + TO-BE (14 files) |
| Procurement | PROC-P1 through PROC-P6 AS-IS + TO-BE (12 files) |
| Administration | ADM all processes AS-IS + TO-BE |
| Project Coordination | NADF_PC_Process1 through Process5 AS-IS (v1.x) + TO-BE (v2.0) — 10 files |
| Legal | NADF_Legal_Process1–4 AS-IS; NADF_Legal_Process1–3 TO-BE (v2.0) — 7 files |

### File naming convention
`NADF_[Dept]_Process[N]_[ProcessName]_[ASIS/TOBE]_Swimlane_v[X.Y].html`

Examples:
- `NADF_PC_Process5_ProjectClosure_ASIS_Swimlane_v1.0.html`
- `NADF_Legal_Process1_ProcurementContracts_Swimlane_v2.0.html`

### Reference documents
- `NADF_SWIMLANE_MASTER_GUIDE.md` — canonical standards reference
- `NADF_BPOGS_Swimlane_Production_Manual_v2.0.docx` — 27-page onboarding manual
- `NADF_BPOGS_Examples_Section10_v2.0.docx` — worked examples
- `NADF_BPOGS_PendingActions_ClientClarifications.docx` — outstanding gaps

---

## SECTION 7 — APPROVAL WORKFLOW REQUIREMENTS

### Multi-level approval principles (from TO-BE workbooks)
- All procurement above threshold requires multi-level Odoo approval
- Finance expenditure requires dual authorisation (initiating department + Finance)
- Legal contract execution requires LSU review + ES/CEO sign-off
- HR actions (appointments, separations, promotions) require HR + CEO approval
- Project milestone approvals require PM + Director sign-off

### Odoo implementation
- `approval` module configured for Phase 1 multi-level flows
- Department-specific approval chains to be configured per TO-BE diagrams
- Approval audit trail must be maintained in Odoo

---

## SECTION 8 — PRODUCT BACKLOG (SUMMARY)

Full backlog detail is in `docs/PRODUCT_BACKLOG.md` (delivered in repo scaffold). Summary by category:

| Category | Items | Done | In Progress | Not Started | Blocked |
|----------|-------|------|------------|-------------|---------|
| Swimlane diagrams (all depts) | ~120 | ~55 | 2 | ~65 | 2 |
| Odoo ERP configuration | ~30 | ~15 | ~8 | ~7 | 0 |
| Custom modules | ~5 | 0 | 0 | ~5 | 0 |
| Reporting/dashboards | 5 | 0 | 1 | 4 | 0 |
| Security/access rights | 4 | 0 | 2 | 2 | 0 |
| Cross-functional workflows | 3 | 0 | 0 | 3 | 0 |
| UAT/deployment | 3 | 0 | 1 | 2 | 0 |

---

## SECTION 9 — PHASED ROADMAP

### Phase 0 — Engagement Setup ✅ COMPLETE
- Workbook framework established
- Master guide and onboarding manual produced
- 20 architectural standards locked

### Phase 1 — Business Process Documentation 🔄 IN PROGRESS (~45%)
- All 12 departments mapped AS-IS + Detailed TO-BE
- All swimlane HTML files produced and approved
- Pending actions document maintained
- **Active:** Legal Services Unit (P5 AS-IS; P4–P6 TO-BE)
- **Next:** Strategy & Planning (P1–P5 AS-IS + TO-BE)
- **Queued:** Communications, Sustainable Agriculture, Investment, M&E, Executive Management

### Phase 2 — Odoo ERP Configuration 🔄 IN PROGRESS (~30%)
- Finance, Procurement, HR, Admin: Phase 1 live
- Project Coordination: Pending
- Legal, Strategy, remaining depts: Pending TO-BE completion
- Executive dashboard, 2FA, facility management: In progress

### Phase 3 — UAT & Super User Training ⏳ NOT STARTED
- Full UAT cycle (currently 50% complete on Phase 1 modules only)
- Super User Acceptance Testing
- Training documentation

### Phase 4 — Production Deployment ⏳ NOT STARTED
- Go-live (Phase 1 modules at 70%)
- Cutover plan
- Data migration validation

### Phase 5 — Hypercare & Phase 2 Features ⏳ NOT STARTED
- Post-go-live stabilisation
- Phase 2 features: Document Management, AI/automation enhancements, public sector template extraction

---

## SECTION 10 — MILESTONE PLAN

Full milestone register is in `docs/MILESTONE_REGISTER.md`. Key upcoming milestones:

| ID | Milestone | Status | Dependency |
|----|-----------|--------|-----------|
| M-LSU-05 | Legal P5 AS-IS + P4–P6 TO-BE | 🔄 Active | — |
| M-STR-01 | Strategy P1–P5 AS-IS + TO-BE | ⏳ Next | Legal complete + workbooks uploaded |
| M-COM-01 | Communications all processes | ⏳ | Strategy complete |
| M-SA-01 | Sustainable Agriculture all processes | ⏳ | — |
| M-INV-01 | Investment all processes | ⏳ | — |
| M-ME-01 | M&E all processes | ⏳ | — |
| M-EXEC-01 | Executive Management all processes | ⏳ | — |
| M-ERP-PC | Project Coordination Odoo config | ⏳ | M-PC-05 done ✅ |
| M-UAT-01 | Full UAT cycle | ⏳ | Phase 2 complete |
| M-DEPLOY-01 | Production go-live | ⏳ | UAT passed |

---

## SECTION 11 — GOVERNANCE REQUIREMENTS

### Repository governance (Claude Code must implement)
- Git branching: feature branches per milestone; PRs required before merge to main
- Branch protection on `main`: no direct push; PR + review required
- CI workflows: lint, test, Odoo module validation on each PR
- Commit message format: `[DEPT-MILESTONE] Brief description`
- All control documents updated before milestone branch is merged

### Document governance
- `docs/CONTROL_TOWER.md` — updated after every milestone
- `docs/PRODUCT_BACKLOG.md` — statuses updated every session
- `docs/MILESTONE_REGISTER.md` — updated on milestone completion
- `docs/IMPLEMENTATION_HISTORY.md` — entry added per milestone
- `docs/DECISION_LOG.md` — entry added per decision
- `CHANGELOG.md` — updated every session
- `docs/session_logs/YYYY-MM-DD_SESSION_SUMMARY.md` — created every session

### Backup governance
- Odoo database backup status: unknown — Claude Code must verify and establish schedule
- Repository backup: GitHub remote (verify remote is set and pushing)

---

## SECTION 12 — REQUIRED DISCOVERY ACTIONS FOR CLAUDE CODE

**Claude Code must complete all of the following before implementing anything.**

### Repository discovery
```bash
# 1. Confirm repo location
ls /Users/mac/nadf_erp

# 2. Git status
cd /Users/mac/nadf_erp && git status && git log --oneline -20

# 3. GitHub remote
git remote -v

# 4. Branch protection (check via GitHub CLI or GitHub UI)
gh repo view --json defaultBranchRef

# 5. CI workflows
ls .github/workflows/

# 6. Existing governance docs
ls docs/

# 7. Existing custom modules
ls addons/ || ls custom_addons/

# 8. Existing configs
ls *.conf || ls config/
```

### Odoo discovery
```bash
# 9. Odoo version
python3 /Users/mac/odoo17/odoo-bin --version

# 10. Odoo database name
psql -U odoo -l | grep nadf

# 11. Addons path
grep addons_path /Users/mac/odoo17/*.conf

# 12. Installed modules (run in Odoo shell or psql)
# SELECT name, state FROM ir_module_module WHERE state = 'installed' ORDER BY name;

# 13. Backup status
ls ~/odoo_backups/ || ls /var/backups/odoo/
```

### After discovery
Report findings in this format before doing anything else:

```
DISCOVERY REPORT
================
Repo path: [confirmed/not found]
Git branch: [branch name]
GitHub remote: [URL or not set]
Branch protection: [yes/no]
CI workflows: [list or none]
Existing docs/: [list]
Existing addons: [list]
Odoo version: [version]
Odoo DB: [name]
Installed modules: [count + key modules]
Backup status: [found/not found/schedule]
Governance docs present: [yes/no — list what exists]
```

Only after this report is confirmed may Claude Code convert the transfer package into repository memory and begin implementation.

---

## SECTION 13 — IMPLEMENTATION SEQUENCE

After discovery, implement in this sequence:

1. **Commit repo scaffold** — place `docs/` structure from transfer package into repo; commit to `main` as `[SETUP] Add repository control tower and governance scaffold`
2. **Update CONTROL_TOWER.md** — with actual git branch, PR status, Odoo DB name, backup status
3. **Legal P5 AS-IS swimlane** — complete production (active milestone)
4. **Legal P4–P6 TO-BE swimlanes** — sequential
5. **Strategy department** — P1–P5 AS-IS + TO-BE (requires workbook upload from client)
6. **Remaining departments** — Communications → Sustainable Agriculture → Investment → M&E → Executive Management
7. **Odoo Project Coordination config** — module configuration
8. **Phase 2 ERP features** — dashboard, 2FA, facility management, fuel tracking
9. **UAT** — full cycle
10. **Production deployment**

---

## SECTION 14 — CONTROL TOWER STRUCTURE

The repository control tower files are delivered separately as `NADF_ERP_ControlTower_RepoScaffold_2026-06-16.zip`. Contents:

```
docs/
  PRODUCT_STATE_INDEX.md       ← Start here every session
  CONTROL_TOWER.md             ← Current programme state
  PRODUCT_BACKLOG.md           ← All work items
  MILESTONE_REGISTER.md        ← Milestone history + queue
  DECISION_LOG.md              ← 20 locked decisions
  IMPLEMENTATION_HISTORY.md    ← Completed milestone records
  departments/status/
    legal_status.md
    hr_status.md
    finance_status.md
    procurement_status.md
    admin_status.md
    project_coordination_status.md
    strategy_status.md
    communications_status.md
    sustainable_agriculture_status.md
    investment_status.md
    me_status.md
    executive_management_status.md
  session_logs/
    2026-06-16_SESSION_SUMMARY.md
CHANGELOG.md
```

---

## SECTION 15 — SESSION START / END RULES FOR CLAUDE CODE

### Session start (mandatory — do not skip)
1. Read `docs/PRODUCT_STATE_INDEX.md`
2. Read `docs/CONTROL_TOWER.md`
3. Read `docs/PRODUCT_BACKLOG.md`
4. Read `docs/MILESTONE_REGISTER.md`
5. Read current department status file
6. Read latest `docs/IMPLEMENTATION_HISTORY.md`
7. Read latest `CHANGELOG.md`
8. Run `git status` + `git log --oneline -10`

Then state:
- Current phase
- Current milestone
- Current blockers
- Next recommended action

**Do not begin work until this state is confirmed.**

### Session end (mandatory — no milestone is complete without this)
1. Update `docs/CONTROL_TOWER.md`
2. Update `docs/PRODUCT_BACKLOG.md`
3. Update `docs/MILESTONE_REGISTER.md`
4. Update relevant department status file
5. Update `docs/IMPLEMENTATION_HISTORY.md`
6. Update `docs/DECISION_LOG.md` (if decision made)
7. Update `CHANGELOG.md`
8. Create `docs/session_logs/YYYY-MM-DD_SESSION_SUMMARY.md`
9. Commit all control document updates

---

## SECTION 16 — CLAUDE DESKTOP / CLAUDE CODE BOUNDARY

| Responsibility | Claude Desktop | Claude Code |
|---------------|----------------|------------|
| Business process materials | ✅ | Read-only (via transfer package) |
| BPOGS workbooks and outputs | ✅ | Read-only |
| Swimlane diagram production | ✅ | No |
| ERP mapping and requirements | ✅ | Read (executes in Odoo) |
| Local repository (`/Users/mac/nadf_erp`) | ❌ No access | ✅ |
| Odoo instance (`/Users/mac/odoo17`) | ❌ No access | ✅ |
| GitHub remote | ❌ No access | ✅ |
| Odoo database | ❌ No access | ✅ |
| Custom module development | ❌ | ✅ |
| Control document updates (repo) | Provides content | Commits to repo |
| Git history | ❌ Cannot inspect | ✅ |

**Claude Desktop must never claim to have inspected the local repository, Odoo instance, GitHub state, or database unless the user explicitly provides that information in the project folder.**

---

*End of NADF Full Product Transfer Package — 2026-06-16*  
*Prepared by Claude Desktop from NADF BPOGS project folder materials only.*
