# NADF ERP — Milestone Register

**Last updated:** 2026-06-16

---

## Milestone Status Legend
- ✅ Complete
- 🔄 In Progress
- ⏳ Not Started
- ❌ Blocked

---

## Completed Milestones

| ID | Phase | Department | Scope | Status | Deliverables | Approval |
|----|-------|-----------|-------|--------|-------------|---------|
| M-000 | 0 | All | Engagement setup; workbook framework; master guide; onboarding manual | ✅ | `NADF_SWIMLANE_MASTER_GUIDE.md`; `NADF_BPOGS_Swimlane_Production_Manual_v2.0.docx` (27pp); companion examples doc | Approved |
| M-HR-01 | 1 | HR | All HR processes (P1–P8) AS-IS + Detailed TO-BE swimlanes | ✅ | 16 HTML swimlane files | Approved |
| M-PROC-01 | 1 | Procurement | All Procurement processes AS-IS + Detailed TO-BE swimlanes | ✅ | 12 HTML swimlane files | Approved (B-02, B-03 open) |
| M-FIN-01 | 1 | Finance | All Finance processes (P1–P7) AS-IS + Detailed TO-BE swimlanes | ✅ | 14 HTML swimlane files | Approved |
| M-ADM-01 | 1 | Administration | All Admin processes AS-IS + Detailed TO-BE swimlanes | ✅ | HTML swimlane files | Approved |
| M-PC-01 | 1 | Project Coordination | PC P1 Project Initiation AS-IS + TO-BE | ✅ | 2 HTML files (v1.3, v2.0) | Approved |
| M-PC-02 | 1 | Project Coordination | PC P2 Project Planning AS-IS + TO-BE | ✅ | 2 HTML files (v1.2, v2.0) | Approved |
| M-PC-03 | 1 | Project Coordination | PC P3 Project Execution AS-IS + TO-BE | ✅ | 2 HTML files (v1.0, v2.0) | Approved |
| M-PC-04 | 1 | Project Coordination | PC P4 Monitoring & Control AS-IS + TO-BE | ✅ | 2 HTML files (v1.0, v2.0) | Approved |
| M-PC-05 | 1 | Project Coordination | PC P5 Project Closure AS-IS + TO-BE | ✅ | 2 HTML files (v1.0, v2.0) | Approved |
| M-LSU-01 | 1 | Legal | Legal P1 Procurement Contracts AS-IS | ✅ | 1 HTML file | Approved |
| M-LSU-02 | 1 | Legal | Legal P2 AS-IS | ✅ | 1 HTML file | Approved |
| M-LSU-03 | 1 | Legal | Legal P3 AS-IS | ✅ | 1 HTML file | Approved |
| M-LSU-04 | 1 | Legal | Legal P4 AS-IS | ✅ | 1 HTML file | Approved |
| M-LSU-TO-01 | 1 | Legal | Legal P1 Detailed TO-BE | ✅ | 1 HTML file | Approved |
| M-LSU-TO-02 | 1 | Legal | Legal P2 Detailed TO-BE | ✅ | 1 HTML file | Approved |
| M-LSU-TO-03 | 1 | Legal | Legal P3 Detailed TO-BE | ✅ | 1 HTML file | Approved |
| M-ERP-01 | 2 | Finance | Odoo chart of accounts, vendor bills, invoicing — Phase 1 live | ✅ | Odoo config | Approved |
| M-ERP-02 | 2 | Procurement | Odoo procurement pipeline — Phase 1 live | ✅ | Odoo config | Approved |
| M-ERP-03 | 2 | HR | Odoo employee records, org chart, leave — Phase 1 live | ✅ | Odoo config | Approved |
| M-ERP-04 | 2 | Admin | Fleet, assets, ICT helpdesk configured | ✅ | Odoo config | Approved |
| M-RPT-01 | 2 | All | ERP Project Status Report v3 (NADF_ERP_Project_Status_Report_v3.docx) | ✅ | .docx report | Delivered |

---

## In Progress Milestones

| ID | Phase | Department | Scope | Status | Blocker |
|----|-------|-----------|-------|--------|---------|
| M-LSU-05 | 1 | Legal | Legal P5 AS-IS swimlane (dual START triggers, HLSU accountability note) | 🔄 | None — in production |
| M-LSU-TO-04 | 1 | Legal | Legal P4 Detailed TO-BE | 🔄 | Awaiting P5 AS-IS approval |

---

## Upcoming Milestones

| ID | Phase | Department | Scope | Dependency |
|----|-------|-----------|-------|-----------|
| M-LSU-TO-05 | 1 | Legal | Legal P5 Detailed TO-BE | M-LSU-05 approved |
| M-LSU-TO-06 | 1 | Legal | Legal P6 Detailed TO-BE (if P6 exists) | M-LSU-TO-05 approved |
| M-STR-01 | 1 | Strategy | Strategy P1–P5 AS-IS swimlanes | Legal complete; workbooks uploaded |
| M-STR-TO-01 | 1 | Strategy | Strategy P1–P5 Detailed TO-BE swimlanes | M-STR-01 approved |
| M-COM-01 | 1 | Communications | All processes AS-IS + TO-BE | Strategy complete |
| M-SA-01 | 1 | Sustainable Agriculture | All processes AS-IS + TO-BE | — |
| M-INV-01 | 1 | Investment | All processes AS-IS + TO-BE | — |
| M-ME-01 | 1 | M&E | All processes AS-IS + TO-BE | — |
| M-EXEC-01 | 1 | Executive Management | All processes AS-IS + TO-BE | — |
| M-ERP-LSU | 2 | Legal | Odoo Legal module configuration | M-LSU-TO complete |
| M-ERP-STR | 2 | Strategy | Odoo Project/Strategy configuration | M-STR-TO complete |
| M-UAT-01 | 3 | All | User Acceptance Testing — full cycle | Phase 2 complete |
| M-DEPLOY-01 | 4 | All | Production go-live | UAT passed |

---

*Updated after every milestone. See CONTROL_TOWER.md for current active milestone.*
